create
    definer = root@localhost procedure select_all_instock_details()
BEGIN
    SELECT *
    FROM in_stock
        LEFT JOIN in_stock_item ON in_stock.in_stock_id = in_stock_item.in_stock_id;
END;

