create
    definer = root@localhost procedure select_all_orders_details()
BEGIN
    SELECT *
    FROM orders
             LEFT JOIN orders_item ON orders.orders_id = orders_item.orders_id;
END;

