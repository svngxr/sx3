create
    definer = root@localhost procedure select_all_outstock_details()
BEGIN
    SELECT *
    FROM out_stock
             LEFT JOIN out_stock_item ON out_stock.out_stock_id = out_stock_item.out_stock_id;
END;

