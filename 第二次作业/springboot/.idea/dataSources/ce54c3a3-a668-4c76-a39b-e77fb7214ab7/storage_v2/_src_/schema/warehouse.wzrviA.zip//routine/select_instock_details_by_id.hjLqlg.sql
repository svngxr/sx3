create
    definer = root@localhost procedure select_instock_details_by_id(IN p_instock_id int)
BEGIN
    SELECT *
    FROM in_stock
        LEFT JOIN in_stock_item ON in_stock.in_stock_id = in_stock_item.in_stock_id
    WHERE in_stock.in_stock_id = p_instock_id;
END;

