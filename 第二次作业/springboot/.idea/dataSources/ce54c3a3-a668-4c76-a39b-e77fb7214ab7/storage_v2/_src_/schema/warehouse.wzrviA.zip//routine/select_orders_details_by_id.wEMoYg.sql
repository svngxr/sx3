create
    definer = root@localhost procedure select_orders_details_by_id(IN p_orders_id int)
BEGIN
    SELECT *
    FROM orders
             LEFT JOIN orders_item ON orders.orders_id = orders_item.orders_id
    WHERE orders.orders_id = p_orders_id;
END;

