create
    definer = root@localhost procedure select_outstock_details_by_id(IN p_outstock_id int)
BEGIN
    SELECT *
    FROM out_stock
             LEFT JOIN out_stock_item ON out_stock.out_stock_id = out_stock_item.out_stock_id
    WHERE out_stock.out_stock_id = p_outstock_id;
END;

