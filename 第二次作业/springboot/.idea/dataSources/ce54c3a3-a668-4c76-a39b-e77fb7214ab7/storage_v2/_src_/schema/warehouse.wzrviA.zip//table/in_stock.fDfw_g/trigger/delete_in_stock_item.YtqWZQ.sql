create definer = root@localhost trigger delete_in_stock_item
    after delete
    on in_stock
    for each row
BEGIN
    DELETE FROM in_stock_item WHERE in_stock_id = OLD.in_stock_id;
END;

