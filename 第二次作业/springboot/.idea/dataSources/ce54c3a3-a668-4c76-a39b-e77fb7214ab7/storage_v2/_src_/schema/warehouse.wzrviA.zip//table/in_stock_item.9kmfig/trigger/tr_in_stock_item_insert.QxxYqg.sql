create definer = root@localhost trigger tr_in_stock_item_insert
    after insert
    on in_stock_item
    for each row
BEGIN
UPDATE in_stock
SET total_price = total_price + NEW.in_stock_price * NEW.in_stock_quantity
WHERE in_stock_id = NEW.in_stock_id;
END;

