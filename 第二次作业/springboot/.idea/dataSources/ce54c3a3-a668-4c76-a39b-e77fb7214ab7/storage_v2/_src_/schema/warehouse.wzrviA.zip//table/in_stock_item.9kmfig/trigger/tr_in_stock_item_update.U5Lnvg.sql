create definer = root@localhost trigger tr_in_stock_item_update
    after update
    on in_stock_item
    for each row
BEGIN
UPDATE in_stock
SET total_price = total_price - OLD.in_stock_price * OLD.in_stock_quantity + NEW.in_stock_price * NEW.in_stock_quantity
WHERE in_stock_id = OLD.in_stock_id;
END;

