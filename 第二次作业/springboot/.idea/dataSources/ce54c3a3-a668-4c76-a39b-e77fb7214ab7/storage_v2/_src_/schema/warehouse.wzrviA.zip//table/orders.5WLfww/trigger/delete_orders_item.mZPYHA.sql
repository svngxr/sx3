create definer = root@localhost trigger delete_orders_item
    after delete
    on orders
    for each row
BEGIN
    DELETE FROM orders_item WHERE orders_id = OLD.orders_id;
END;

