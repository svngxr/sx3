create definer = root@localhost trigger update_stock_quantity
    after update
    on orders_item
    for each row
BEGIN
DECLARE difference INT;
DECLARE new_stock_quantity INT;

SELECT (OLD.return_quantity - NEW.return_quantity) INTO difference;

IF NEW.return_quantity > NEW.quantity OR NEW.return_quantity < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'return_quantity must be greater than 0 and less than or equal to quantity';
ELSEIF difference > 0 THEN
    SELECT stock_quantity + difference INTO new_stock_quantity FROM stock WHERE product_id = NEW.product_id;
    IF new_stock_quantity < 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Not enough stock available';
    ELSE
        UPDATE stock SET stock_quantity = new_stock_quantity WHERE product_id = NEW.product_id;
    END IF;
ELSEIF difference < 0 THEN
    SELECT stock_quantity + difference INTO new_stock_quantity FROM stock WHERE product_id = NEW.product_id;
    UPDATE stock SET stock_quantity = new_stock_quantity WHERE product_id = NEW.product_id;
END IF;
END;

