create definer = root@localhost trigger update_total_price_delete
    after delete
    on orders_item
    for each row
BEGIN
UPDATE orders SET total_price = total_price - OLD.quantity * OLD.price WHERE orders_id = OLD.orders_id;
END;

