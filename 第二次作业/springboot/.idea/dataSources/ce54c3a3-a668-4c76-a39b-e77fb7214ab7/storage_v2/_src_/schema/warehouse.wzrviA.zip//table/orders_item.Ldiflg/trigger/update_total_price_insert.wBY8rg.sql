create definer = root@localhost trigger update_total_price_insert
    after insert
    on orders_item
    for each row
BEGIN
UPDATE orders SET total_price = total_price + NEW.quantity * NEW.price WHERE orders_id = NEW.orders_id;
END;

