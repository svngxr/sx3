create definer = root@localhost trigger update_total_price_update
    after update
    on orders_item
    for each row
BEGIN
UPDATE orders SET total_price = total_price - OLD.quantity * OLD.price + NEW.quantity * NEW.price WHERE orders_id = NEW.orders_id;
END;

