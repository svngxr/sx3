create definer = root@localhost trigger delete_out_stock_item
    after delete
    on out_stock
    for each row
BEGIN
    DELETE FROM out_stock_item WHERE out_stock_id = OLD.out_stock_id;
END;

