create definer = root@localhost trigger tr_out_stock_item_delete
    after delete
    on out_stock_item
    for each row
BEGIN
UPDATE out_stock
SET total_price = total_price - OLD.out_stock_price * OLD.out_stock_quantity
WHERE out_stock_id = OLD.out_stock_id;
END;

