create definer = root@localhost trigger tr_out_stock_item_insert
    after insert
    on out_stock_item
    for each row
BEGIN
UPDATE out_stock
SET total_price = total_price + NEW.out_stock_price * NEW.out_stock_quantity
WHERE out_stock_id = NEW.out_stock_id;
END;

